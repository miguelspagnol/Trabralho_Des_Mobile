package com.example.bibliotecapessoal.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.example.bibliotecapessoal.model.Livro

/**
 * Estado compartilhado entre Listagem, Cadastro e Detalhes.
 * Uma única instância é criada acima do NavHost, então todas as telas
 * enxergam a mesma coleção.
 */
class LivroViewModel : ViewModel() {

    private val _livros = mutableStateListOf(
        Livro(
            id = 1,
            titulo = "Dom Casmurro",
            autor = "Machado de Assis",
            ano = 1899,
            genero = "Romance",
            sinopse = "Bentinho narra sua vida e a dúvida sobre a fidelidade de Capitu."
        ),
        Livro(
            id = 2,
            titulo = "O Cortiço",
            autor = "Aluísio Azevedo",
            ano = 1890,
            genero = "Naturalismo",
            sinopse = "Retrato da vida em um cortiço do Rio de Janeiro no século XIX."
        ),
        Livro(
            id = 3,
            titulo = "Capitães da Areia",
            autor = "Jorge Amado",
            ano = 1937,
            genero = "Romance",
            sinopse = "A história de um grupo de meninos de rua em Salvador."
        )
    )

    /** Lista observável: a interface é recomposta quando ela muda. */
    val livros: List<Livro> get() = _livros

    private var proximoId = (_livros.maxOfOrNull { it.id } ?: 0) + 1

    fun adicionar(
        titulo: String,
        autor: String,
        ano: Int,
        genero: String,
        sinopse: String
    ): Livro {
        val novo = Livro(
            id = proximoId++,
            titulo = titulo.trim(),
            autor = autor.trim(),
            ano = ano,
            genero = genero.trim(),
            sinopse = sinopse.trim()
        )
        _livros.add(novo)
        return novo
    }

    /** Retorna null quando o ID não existe. */
    fun buscarPorId(id: Int?): Livro? =
        if (id == null) null else _livros.firstOrNull { it.id == id }
}
