package com.example.bibliotecapessoal.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.bibliotecapessoal.screens.CadastroScreen
import com.example.bibliotecapessoal.screens.DetalhesScreen
import com.example.bibliotecapessoal.screens.HomeScreen
import com.example.bibliotecapessoal.screens.SobreScreen
import com.example.bibliotecapessoal.viewmodel.LivroViewModel

@Composable
fun AppNavigation(modifier: Modifier = Modifier) {
    val navController = rememberNavController()

    // Criado acima dos destinos (escopo da Activity): uma única coleção para todas as telas.
    val livroViewModel: LivroViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        modifier = modifier
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                livros = livroViewModel.livros,
                onAbrirDetalhes = { id ->
                    navController.navigate(Routes.detalhes(id)) { launchSingleTop = true }
                },
                onAbrirCadastro = {
                    navController.navigate(Routes.CADASTRO) { launchSingleTop = true }
                },
                onAbrirSobre = {
                    navController.navigate(Routes.SOBRE) { launchSingleTop = true }
                }
            )
        }

        composable(Routes.CADASTRO) {
            CadastroScreen(
                onSalvar = { titulo, autor, ano, genero, sinopse ->
                    livroViewModel.adicionar(titulo, autor, ano, genero, sinopse)
                    // Volta para a lista removendo o cadastro da pilha (sem duplicar telas).
                    navController.popBackStack()
                },
                onCancelar = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.DETALHES,
            arguments = listOf(
                navArgument(Routes.ARG_LIVRO_ID) { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getInt(Routes.ARG_LIVRO_ID)
            DetalhesScreen(
                livro = livroViewModel.buscarPorId(id),
                onVoltar = { navController.popBackStack() }
            )
        }

        composable(Routes.SOBRE) {
            SobreScreen(onVoltar = { navController.popBackStack() })
        }
    }
}
