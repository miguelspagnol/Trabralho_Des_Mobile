package com.example.bibliotecapessoal.navigation

/** Rotas do aplicativo, centralizadas em um único arquivo. */
object Routes {
    const val ARG_LIVRO_ID = "livroId"

    const val HOME = "home"
    const val CADASTRO = "cadastro"
    const val DETALHES = "detalhes/{$ARG_LIVRO_ID}"
    const val SOBRE = "sobre"

    fun detalhes(id: Int) = "detalhes/$id"
}
