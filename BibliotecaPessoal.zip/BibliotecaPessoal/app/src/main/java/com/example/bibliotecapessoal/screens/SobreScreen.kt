package com.example.bibliotecapessoal.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

// TODO: troque pelo(s) nome(s) do(s) autor(es) do trabalho.
private const val AUTORES = "Seu Nome (e colegas de grupo, se houver)"

private const val TEXTO_COMPARTILHAMENTO =
    "Conheça o app Biblioteca Pessoal, um projeto acadêmico em Kotlin com Jetpack Compose " +
        "para cadastrar livros, consultar a lista e ver os detalhes de cada obra. " +
        "Desenvolvido por $AUTORES."

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SobreScreen(onVoltar: () -> Unit) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sobre / Ajuda") },
                navigationIcon = {
                    IconButton(onClick = onVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Biblioteca Pessoal", style = MaterialTheme.typography.headlineSmall)

            Secao(
                titulo = "Finalidade",
                texto = "Organizar sua coleção de livros: ver a lista, cadastrar novas obras " +
                    "e consultar os detalhes de cada uma."
            )
            Secao(
                titulo = "Como usar",
                texto = "1. Na tela inicial, toque em \"Detalhes\" para ver as informações de um livro.\n" +
                    "2. Toque em \"Novo livro\" para abrir o formulário de cadastro.\n" +
                    "3. Preencha título, autor e ano (campos obrigatórios) e toque em \"Salvar\".\n" +
                    "4. O livro aparece na lista automaticamente. Use \"Cancelar\" para sair sem salvar."
            )
            Secao(titulo = "Autor(es)", texto = AUTORES)

            Button(
                onClick = { compartilharApp(context) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Compartilhar aplicativo")
            }
            OutlinedButton(onClick = onVoltar, modifier = Modifier.fillMaxWidth()) {
                Text("Voltar")
            }
        }
    }
}

@Composable
private fun Secao(titulo: String, texto: String) {
    Column {
        Text(
            text = titulo,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(text = texto, style = MaterialTheme.typography.bodyMedium)
    }
}

/** Intent implícito ACTION_SEND com seletor; trata a ausência de app compatível. */
private fun compartilharApp(context: Context) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Biblioteca Pessoal")
        putExtra(Intent.EXTRA_TEXT, TEXTO_COMPARTILHAMENTO)
    }
    try {
        context.startActivity(Intent.createChooser(intent, "Compartilhar aplicativo"))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(
            context,
            "Nenhum aplicativo disponível para compartilhar.",
            Toast.LENGTH_SHORT
        ).show()
    }
}
