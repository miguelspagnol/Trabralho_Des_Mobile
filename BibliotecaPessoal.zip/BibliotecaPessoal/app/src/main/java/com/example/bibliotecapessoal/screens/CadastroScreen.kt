package com.example.bibliotecapessoal.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CadastroScreen(
    onSalvar: (titulo: String, autor: String, ano: Int, genero: String, sinopse: String) -> Unit,
    onCancelar: () -> Unit
) {
    var titulo by rememberSaveable { mutableStateOf("") }
    var autor by rememberSaveable { mutableStateOf("") }
    var ano by rememberSaveable { mutableStateOf("") }
    var genero by rememberSaveable { mutableStateOf("") }
    var sinopse by rememberSaveable { mutableStateOf("") }
    var tentouSalvar by rememberSaveable { mutableStateOf(false) }

    val anoAtual = Calendar.getInstance().get(Calendar.YEAR)
    val anoNumero = ano.trim().toIntOrNull()

    // Mensagens de erro (null = campo válido)
    val erroTitulo = if (titulo.isBlank()) "O título é obrigatório." else null
    val erroAutor = when {
        autor.isBlank() -> "O autor é obrigatório."
        autor.trim().length < 3 -> "O nome do autor deve ter pelo menos 3 caracteres."
        else -> null
    }
    val erroAno = when {
        ano.isBlank() -> "Informe o ano de publicação."
        anoNumero == null -> "Digite apenas números."
        anoNumero <= 0 -> "O ano deve ser um número positivo."
        anoNumero > anoAtual -> "O ano não pode ser maior que $anoAtual."
        else -> null
    }
    val formularioValido = erroTitulo == null && erroAutor == null && erroAno == null

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Novo livro") },
                navigationIcon = {
                    IconButton(onClick = onCancelar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = titulo,
                onValueChange = { titulo = it },
                label = { Text("Título *") },
                isError = tentouSalvar && erroTitulo != null,
                supportingText = { if (tentouSalvar && erroTitulo != null) Text(erroTitulo) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = autor,
                onValueChange = { autor = it },
                label = { Text("Autor *") },
                isError = tentouSalvar && erroAutor != null,
                supportingText = { if (tentouSalvar && erroAutor != null) Text(erroAutor) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = ano,
                onValueChange = { ano = it },
                label = { Text("Ano de publicação *") },
                isError = tentouSalvar && erroAno != null,
                supportingText = { if (tentouSalvar && erroAno != null) Text(erroAno) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = genero,
                onValueChange = { genero = it },
                label = { Text("Gênero") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = sinopse,
                onValueChange = { sinopse = it },
                label = { Text("Sinopse") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(onClick = onCancelar, modifier = Modifier.weight(1f)) {
                    Text("Cancelar")
                }
                Button(
                    onClick = {
                        tentouSalvar = true
                        if (formularioValido && anoNumero != null) {
                            onSalvar(
                                titulo,
                                autor,
                                anoNumero,
                                genero.ifBlank { "Não informado" },
                                sinopse.ifBlank { "Sem sinopse." }
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Salvar")
                }
            }
        }
    }
}
