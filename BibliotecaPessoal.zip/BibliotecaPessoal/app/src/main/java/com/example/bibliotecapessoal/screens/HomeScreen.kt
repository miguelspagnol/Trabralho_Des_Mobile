package com.example.bibliotecapessoal.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.bibliotecapessoal.model.Livro

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    livros: List<Livro>,
    onAbrirDetalhes: (Int) -> Unit,
    onAbrirCadastro: () -> Unit,
    onAbrirSobre: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Biblioteca Pessoal") },
                actions = {
                    TextButton(onClick = onAbrirSobre) { Text("Sobre / Ajuda") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAbrirCadastro,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Novo livro") }
            )
        }
    ) { innerPadding ->
        if (livros.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Nenhum livro cadastrado ainda.")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                // espaço extra no fim para o botão flutuante não cobrir o último item
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(livros, key = { it.id }) { livro ->
                    LivroItem(livro = livro, onAbrirDetalhes = { onAbrirDetalhes(livro.id) })
                }
            }
        }
    }
}

@Composable
private fun LivroItem(livro: Livro, onAbrirDetalhes: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = livro.titulo, style = MaterialTheme.typography.titleMedium)
                Text(text = livro.autor, style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = "${livro.genero} • ${livro.ano}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            TextButton(onClick = onAbrirDetalhes) { Text("Detalhes") }
        }
    }
}
