package com.example.bibliotecapessoal.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.bibliotecapessoal.model.Livro

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetalhesScreen(
    livro: Livro?,
    onVoltar: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalhes do livro") },
                navigationIcon = {
                    IconButton(onClick = onVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (livro == null) {
            // ID inexistente: mensagem amigável, sem falha no aplicativo
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Livro não encontrado.",
                    style = MaterialTheme.typography.titleMedium
                )
                Text("O item solicitado não existe ou foi removido.")
                Button(onClick = onVoltar) { Text("Voltar") }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(text = livro.titulo, style = MaterialTheme.typography.headlineSmall)
                Campo(rotulo = "Código (ID)", valor = livro.id.toString())
                Campo(rotulo = "Autor", valor = livro.autor)
                Campo(rotulo = "Ano de publicação", valor = livro.ano.toString())
                Campo(rotulo = "Gênero", valor = livro.genero)
                Campo(rotulo = "Sinopse", valor = livro.sinopse)

                Button(onClick = onVoltar, modifier = Modifier.fillMaxWidth()) {
                    Text("Voltar")
                }
            }
        }
    }
}

@Composable
private fun Campo(rotulo: String, valor: String) {
    Column {
        Text(
            text = rotulo,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(text = valor, style = MaterialTheme.typography.bodyLarge)
    }
}
