package com.example.bibliotecapessoal.model

/**
 * Modelo de dados da Biblioteca Pessoal.
 * O [id] é único e usado como argumento da rota de detalhes.
 */
data class Livro(
    val id: Int,
    val titulo: String,
    val autor: String,
    val ano: Int,
    val genero: String,
    val sinopse: String
)
